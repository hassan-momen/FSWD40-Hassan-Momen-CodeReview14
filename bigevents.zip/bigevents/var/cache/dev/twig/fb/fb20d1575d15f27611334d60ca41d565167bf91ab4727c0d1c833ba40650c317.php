<?php

/* event/index.html.twig */
class __TwigTemplate_b772d9531c37ff3274f593a1d3cc67d304db851021dfbbfbaafb59d0d8c91ca0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 2
        echo "<!-- carousel -->

<div id=\"carouselExampleIndicators\" class=\"carousel slide \" data-ride=\"carousel \">
    <ol class=\"carousel-indicators\">
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>
    </ol>
    <div class=\"carousel-inner\">
        <div class=\"carousel-item active\">
            <img class=\"d-block w-100\" src=\"https://lh4.googleusercontent.com/uUg03ZwNThy1J70ajPOXk9XUMXWris4ziGYjiLOSmNqkHAEDeTPijtNm4zwG1uwzvlbQhYP7j4WXEkjNQBTPJTmyd0xuumwoYis3YG3kFq0qhmVbKudRywyHAkbTGer_D5KRSzQy\" alt=\"First slide\" style=\"height: 600px; \">
        </div>
        <div class=\"carousel-item\">
            <img class=\"d-block w-100\" src=\"http://diyprintingsupply.com/blog/wp-content/uploads/2013/06/Look-the-Business-hero.jpg\" alt=\"Second slide\" style=\"height: 600px; \">
        </div>
        <div class=\"carousel-item\">
            <img class=\"d-block w-100\" src=\"https://cleeng.com/blog/wp-content/uploads/2015/07/Social-live-events.jpg\" alt=\"Third slide\" style=\"height: 600px; \">
        </div>
    </div>
    <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
  </a>
    <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
  </a>
</div>

<!-- cards -->

<center>
    <h2 class=\"page-header\">Events in Vienna</h2></center>
<div class=\"container\">
    <div class=\"row\">
        ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["bigevents"] ?? $this->getContext($context, "bigevents")));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 38
            echo "        <div class=\"col-lg-4 col-md-6 col-xs-12\">
            <div class=\"card m-3\">
                <img class=\"card-img-top\" src=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "image", array()), "html", null, true);
            echo "\" style=\" width:100%;height:250px;\" alt=\"Card image cap\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "name", array()), "html", null, true);
            echo "</h5>
                    <p class=\"card-text\">";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "address", array()), "html", null, true);
            echo "</p>
                   <a href=";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "EventURL", array()), "html", null, true);
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "EventURL", array()), "html", null, true);
            echo "</a>
                   <p class=\"card-text\">";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "PhoneNumber", array()), "html", null, true);
            echo "</p>
                    <p class=\"card-text\"><small class=\"text-muted\"><a href=\"/event/details/";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-outline-success\">More</a>
             <a href=\"/event/edit/";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-outline-info\">Edit</a>
            <a href=\"/event/delete/";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-outline-danger\">Delete</a></small></p>
                </div>
            </div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "    </div>
</div>

<!--fontawsome -->


<section class=\"boxes\">
    <div class=\"container mt-5\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fas fa-trophy\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fas fa-users\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fa fa-search\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- footer -->

<footer id=\"myFooter\">
    <div class=\"row\">
        <div class=\"col-sm-3 myCols\">
            <h5>Get started</h5>
            <ul>
                <li><a href=\"#\">Home</a></li>
                <li><a href=\"#\">Sign up</a></li>
                <li><a href=\"#\">Downloads</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>About us</h5>
            <ul>
                <li><a href=\"#\">Company Information</a></li>
                <li><a href=\"#\">Contact us</a></li>
                <li><a href=\"#\">Reviews</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>Support</h5>
            <ul>
                <li><a href=\"#\">FAQ</a></li>
                <li><a href=\"#\">Help desk</a></li>
                <li><a href=\"#\">Forums</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>Legal</h5>
            <ul>
                <li><a href=\"#\">Terms of Service</a></li>
                <li><a href=\"#\">Terms of Use</a></li>
                <li><a href=\"#\">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
    <div class=\"footer-copyright\">
        <p>© 2018 Copyright Hassan Momen</p>
    </div>
</footer>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "event/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 53,  124 => 48,  120 => 47,  116 => 46,  112 => 45,  106 => 44,  102 => 43,  98 => 42,  93 => 40,  89 => 38,  85 => 37,  48 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %} {% block body %}
<!-- carousel -->

<div id=\"carouselExampleIndicators\" class=\"carousel slide \" data-ride=\"carousel \">
    <ol class=\"carousel-indicators\">
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>
        <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>
    </ol>
    <div class=\"carousel-inner\">
        <div class=\"carousel-item active\">
            <img class=\"d-block w-100\" src=\"https://lh4.googleusercontent.com/uUg03ZwNThy1J70ajPOXk9XUMXWris4ziGYjiLOSmNqkHAEDeTPijtNm4zwG1uwzvlbQhYP7j4WXEkjNQBTPJTmyd0xuumwoYis3YG3kFq0qhmVbKudRywyHAkbTGer_D5KRSzQy\" alt=\"First slide\" style=\"height: 600px; \">
        </div>
        <div class=\"carousel-item\">
            <img class=\"d-block w-100\" src=\"http://diyprintingsupply.com/blog/wp-content/uploads/2013/06/Look-the-Business-hero.jpg\" alt=\"Second slide\" style=\"height: 600px; \">
        </div>
        <div class=\"carousel-item\">
            <img class=\"d-block w-100\" src=\"https://cleeng.com/blog/wp-content/uploads/2015/07/Social-live-events.jpg\" alt=\"Third slide\" style=\"height: 600px; \">
        </div>
    </div>
    <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
  </a>
    <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
  </a>
</div>

<!-- cards -->

<center>
    <h2 class=\"page-header\">Events in Vienna</h2></center>
<div class=\"container\">
    <div class=\"row\">
        {% for event in bigevents %}
        <div class=\"col-lg-4 col-md-6 col-xs-12\">
            <div class=\"card m-3\">
                <img class=\"card-img-top\" src=\"{{event.image}}\" style=\" width:100%;height:250px;\" alt=\"Card image cap\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">{{event.name}}</h5>
                    <p class=\"card-text\">{{event.address}}</p>
                   <a href={{event.EventURL}}>{{event.EventURL}}</a>
                   <p class=\"card-text\">{{event.PhoneNumber}}</p>
                    <p class=\"card-text\"><small class=\"text-muted\"><a href=\"/event/details/{{event.id}}\" class=\"btn btn-outline-success\">More</a>
             <a href=\"/event/edit/{{event.id}}\" class=\"btn btn-outline-info\">Edit</a>
            <a href=\"/event/delete/{{event.id}}\" class=\"btn btn-outline-danger\">Delete</a></small></p>
                </div>
            </div>
        </div>
        {% endfor %}
    </div>
</div>

<!--fontawsome -->


<section class=\"boxes\">
    <div class=\"container mt-5\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fas fa-trophy\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fas fa-users\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
            <div class=\"col-lg-4 col-sm-12 pb-5\">
                <div class=\"box wow bounceInUp\">
                    <i id=\"icon\" class=\"fa fa-search\"></i>
                    <h3>Lorem ipsum dolor</h3>
                    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</P>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- footer -->

<footer id=\"myFooter\">
    <div class=\"row\">
        <div class=\"col-sm-3 myCols\">
            <h5>Get started</h5>
            <ul>
                <li><a href=\"#\">Home</a></li>
                <li><a href=\"#\">Sign up</a></li>
                <li><a href=\"#\">Downloads</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>About us</h5>
            <ul>
                <li><a href=\"#\">Company Information</a></li>
                <li><a href=\"#\">Contact us</a></li>
                <li><a href=\"#\">Reviews</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>Support</h5>
            <ul>
                <li><a href=\"#\">FAQ</a></li>
                <li><a href=\"#\">Help desk</a></li>
                <li><a href=\"#\">Forums</a></li>
            </ul>
        </div>
        <div class=\"col-sm-3 myCols\">
            <h5>Legal</h5>
            <ul>
                <li><a href=\"#\">Terms of Service</a></li>
                <li><a href=\"#\">Terms of Use</a></li>
                <li><a href=\"#\">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
    <div class=\"footer-copyright\">
        <p>© 2018 Copyright Hassan Momen</p>
    </div>
</footer>
{% endblock %}", "event/index.html.twig", "C:\\xampp\\htdocs\\symfony\\bigevents\\app\\Resources\\views\\event\\index.html.twig");
    }
}
